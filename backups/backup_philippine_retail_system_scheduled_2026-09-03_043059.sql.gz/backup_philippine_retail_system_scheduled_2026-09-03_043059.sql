-- ==============================================================================
-- Triple8 Retail Store Database Backup
-- Database: `philippine_retail_system`
-- Backup Type: scheduled
-- Generated: 2026-09-03 04:30:59
-- Tables: 34
-- Notes: Automated recurring snapshot (interval: 60 mins)
-- ==============================================================================

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = '+08:00';
SET NAMES utf8mb4;

-- -----------------------------------------------------------------------------
-- Table structure for `access_audit_logs`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `access_audit_logs`;
CREATE TABLE `access_audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `target_id` varchar(100) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `status` enum('success','warning','denied') NOT NULL DEFAULT 'success',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_action` (`action`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `access_audit_logs` (93 records)
INSERT INTO `access_audit_logs` (`id`, `user_id`, `username`, `action`, `target_type`, `target_id`, `details`, `ip_address`, `status`, `created_at`) VALUES
('3', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-14 23:33:19'),
('5', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-14 23:44:06'),
('6', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-14 23:46:16'),
('8', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-14 23:56:03'),
('10', '1', NULL, 'LOGIN_FAILED', 'credentials', 'admin', 'Invalid password attempt', '::1', 'denied', '2026-08-18 14:44:29'),
('11', '1', NULL, 'LOGIN_FAILED', 'credentials', 'admin', 'Invalid password attempt', '::1', 'denied', '2026-08-18 14:44:40'),
('12', '1', NULL, 'LOGIN_FAILED', 'credentials', 'admin', 'Invalid password attempt', '::1', 'denied', '2026-08-18 14:44:43'),
('13', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-18 14:45:06'),
('14', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-18 14:54:05'),
('15', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-18 14:54:17'),
('16', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-18 15:03:38'),
('17', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (session_expired)', '::1', 'success', '2026-08-18 17:03:37'),
('18', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-18 17:03:44'),
('19', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-18 17:03:56'),
('20', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-18 17:04:00'),
('21', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-20 14:43:18'),
('22', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-21 00:40:14'),
('23', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-21 22:22:53'),
('24', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-21 22:38:12'),
('25', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-21 22:38:21'),
('26', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-21 22:38:25'),
('27', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-21 22:50:00'),
('28', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-21 22:51:26'),
('29', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-21 22:51:34'),
('30', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-21 22:51:42'),
('31', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-21 23:18:06'),
('32', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 01:12:34'),
('33', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 01:33:40'),
('34', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 10:14:15'),
('35', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 10:15:12'),
('36', NULL, NULL, 'LOGIN_FAILED', 'user', NULL, 'Failed password attempt for username: cashier1', '::1', 'warning', '2026-08-22 10:15:19'),
('37', NULL, NULL, 'LOGIN_FAILED', 'user', NULL, 'Failed password attempt for username: cashier1', '::1', 'warning', '2026-08-22 10:15:24'),
('38', NULL, NULL, 'LOGIN_FAILED', 'user', NULL, 'Username not found: cashier', '::1', 'warning', '2026-08-22 10:15:35'),
('39', NULL, NULL, 'LOGIN_FAILED', 'user', NULL, 'Username not found: cashier', '::1', 'warning', '2026-08-22 10:15:38'),
('40', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 10:15:52'),
('41', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 10:56:54'),
('42', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-08-22 10:57:08'),
('43', '3', 'cashier1', 'LOGOUT', 'session', '3', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 10:58:03'),
('44', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 11:00:21'),
('45', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:00:28'),
('46', NULL, NULL, 'LOGIN_FAILED', 'user', NULL, 'Failed password attempt for username: cashier1', '::1', 'warning', '2026-08-22 11:00:44'),
('47', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-08-22 11:00:53'),
('48', '3', 'cashier1', 'LOGOUT', 'session', '3', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:00:59'),
('49', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 11:01:04'),
('50', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:02:15'),
('51', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 11:02:51'),
('52', '1', 'admin', 'PERMISSION_UPDATE', 'role_matrix', 'all', 'Updated role-permission matrix (30 mappings)', '::1', 'success', '2026-08-22 11:06:42'),
('53', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:06:50'),
('54', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-08-22 11:06:57'),
('55', '3', 'cashier1', 'LOGOUT', 'session', '3', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:07:05'),
('56', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 11:09:56'),
('57', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:10:59'),
('58', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-08-22 11:11:04'),
('59', '3', 'cashier1', 'LOGOUT', 'session', '3', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:11:14'),
('60', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 11:11:18'),
('61', '1', 'admin', 'PERMISSION_UPDATE', 'role_matrix', 'all', 'Updated role-permission matrix (32 mappings)', '::1', 'success', '2026-08-22 11:11:49'),
('62', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:11:56'),
('63', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-08-22 11:12:00'),
('64', '3', 'cashier1', 'LOGOUT', 'session', '3', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:12:10'),
('65', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 11:12:14'),
('66', '1', 'admin', 'PERMISSION_UPDATE', 'role_matrix', 'all', 'Updated role-permission matrix (30 mappings)', '::1', 'success', '2026-08-22 11:12:20'),
('67', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:19:00'),
('68', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-08-22 11:22:47'),
('69', '3', 'cashier1', 'LOGOUT', 'session', '3', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:23:31'),
('70', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 11:32:27'),
('71', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 11:43:37'),
('72', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 11:44:34'),
('73', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (session_expired)', '::1', 'success', '2026-08-22 14:03:29'),
('74', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 14:03:36'),
('75', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 14:14:06'),
('76', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 15:17:30'),
('77', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 15:35:52'),
('78', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-08-22 15:35:58'),
('79', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-08-22 15:35:58'),
('80', '3', 'cashier1', 'LOGOUT', 'session', '3', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 15:36:19'),
('81', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 15:36:24'),
('82', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 19:42:16'),
('83', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-08-22 19:45:36'),
('84', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-22 19:46:14'),
('85', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-08-25 13:24:13'),
('86', NULL, NULL, 'BACKUP_CREATED', 'backup', 'triple8_backup_manual_2026-08-26_13-34-30.sql.gz', 'Created manual backup (13.98 KB, 32 tables, 413 rows in 1.858s)', '127.0.0.1', 'success', '2026-08-26 19:34:32'),
('87', NULL, NULL, 'BACKUP_CREATED', 'backup', 'triple8_backup_scheduled_2026-08-26_13-38-58.sql.gz', 'Created scheduled backup (14.21 KB, 32 tables, 415 rows in 1.035s)', '127.0.0.1', 'success', '2026-08-26 19:38:59'),
('88', NULL, NULL, 'BACKUP_CREATED', 'backup', 'triple8_backup_manual_2026-08-26_13-40-07.sql.gz', 'Created manual backup (14.37 KB, 32 tables, 417 rows in 1.967s)', '127.0.0.1', 'success', '2026-08-26 19:40:09'),
('89', NULL, NULL, 'BACKUP_CREATED', 'backup', 'triple8_backup_manual_2026-08-26_13-40-37.sql.gz', 'Created manual backup (14.48 KB, 32 tables, 419 rows in 1.715s)', '127.0.0.1', 'success', '2026-08-26 19:40:39'),
('90', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-09-02 23:10:09'),
('91', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-09-02 23:11:19'),
('92', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-09-02 23:55:15'),
('93', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-09-03 00:48:32'),
('94', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-09-03 00:55:54'),
('95', '1', 'admin', 'LOGOUT', 'session', '1', 'User logged out (logged_out)', '::1', 'success', '2026-09-03 04:26:20'),
('96', '3', 'cashier1', 'LOGIN_SUCCESS', 'user', '3', 'Successful login for role: cashier', '::1', 'success', '2026-09-03 04:26:25'),
('97', '3', 'cashier1', 'LOGOUT', 'session', '3', 'User logged out (logged_out)', '::1', 'success', '2026-09-03 04:26:47'),
('98', '1', 'admin', 'LOGIN_SUCCESS', 'user', '1', 'Successful login for role: admin', '::1', 'success', '2026-09-03 04:26:51');

-- -----------------------------------------------------------------------------
-- Table structure for `api_keys`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `api_keys`;
CREATE TABLE `api_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_name` varchar(100) NOT NULL,
  `api_key_hash` varchar(64) NOT NULL,
  `key_prefix` varchar(16) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'cashier',
  `allowed_ips` text DEFAULT NULL,
  `rate_limit_per_min` int(11) NOT NULL DEFAULT 60,
  `status` enum('active','revoked','expired') NOT NULL DEFAULT 'active',
  `last_used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_key_hash` (`api_key_hash`),
  KEY `idx_key_hash` (`api_key_hash`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `audit_log`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `audit_log`;
CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_log_user_id` (`user_id`),
  KEY `idx_audit_log_created_at` (`created_at`),
  CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `backup_logs`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `filepath` varchar(500) NOT NULL,
  `filesize_bytes` bigint(20) NOT NULL DEFAULT 0,
  `backup_type` enum('scheduled','checkpoint','manual','pre_restore','emergency') NOT NULL DEFAULT 'manual',
  `status` enum('success','failed','restored') NOT NULL DEFAULT 'success',
  `checksum` varchar(64) DEFAULT NULL,
  `tables_count` int(11) NOT NULL DEFAULT 0,
  `total_rows` int(11) NOT NULL DEFAULT 0,
  `duration_seconds` decimal(6,3) NOT NULL DEFAULT 0.000,
  `created_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_backup_type` (`backup_type`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `backup_logs` (6 records)
INSERT INTO `backup_logs` (`id`, `filename`, `filepath`, `filesize_bytes`, `backup_type`, `status`, `checksum`, `tables_count`, `total_rows`, `duration_seconds`, `created_by`, `notes`, `created_at`) VALUES
('1', 'triple8_backup_manual_2026-08-26_13-34-30.sql.gz', 'C:\\xampp\\htdocs\\Triple8\\backups\\triple8_backup_manual_2026-08-26_13-34-30.sql.gz', '14315', 'manual', 'success', '0777d8aaf7d6ccb1b57792be4b378d38fa10cc0ab7126dc3aa9b5a942151b835', '32', '413', '1.858', NULL, 'Initial verification test backup', '2026-08-26 19:34:32'),
('2', 'triple8_backup_scheduled_2026-08-26_13-38-58.sql.gz', 'C:\\xampp\\htdocs\\Triple8\\backups\\triple8_backup_scheduled_2026-08-26_13-38-58.sql.gz', '14554', 'scheduled', 'success', '67c737793f157954f38f71296fccb7fb7eba5ad09ef70675f602e281969c085b', '32', '415', '1.035', NULL, 'CLI Automated Backup Worker (Power-Loss Protection)', '2026-08-26 19:38:59'),
('3', 'triple8_backup_manual_2026-08-26_13-40-07.sql.gz', 'C:\\xampp\\htdocs\\Triple8\\backups\\triple8_backup_manual_2026-08-26_13-40-07.sql.gz', '14710', 'manual', 'success', '8fee81acaaf3c6d57499b61fcf87a62a8e248e56c48360553fe1a6368ac8b526', '32', '417', '1.967', NULL, 'Comprehensive Test Backup', '2026-08-26 19:40:09'),
('4', 'triple8_backup_manual_2026-08-26_13-40-37.sql.gz', 'C:\\xampp\\htdocs\\Triple8\\backups\\triple8_backup_manual_2026-08-26_13-40-37.sql.gz', '14832', 'manual', 'success', '642c0cad38d7b21deeefbfa8d28025dde223f11b184d925788ac870c49f6644b', '32', '419', '1.715', NULL, 'Comprehensive Test Backup', '2026-08-26 19:40:39'),
('5', 'backup_philippine_retail_system_manual_2026-09-02_204010.sql', 'C:\\xampp\\htdocs\\Triple8\\backups\\backup_philippine_retail_system_manual_2026-09-02_204010.sql', '85484', 'manual', 'success', 'c4732c95f280d09b7c262a4ba6e0eba290424118d8203a8ddd8ae4b4d4224d3c', '34', '422', '0.080', NULL, 'Timezone accuracy verification', '2026-09-02 20:40:10'),
('6', 'backup_philippine_retail_system_scheduled_2026-09-02_204043.sql.gz', 'C:\\xampp\\htdocs\\Triple8\\backups\\backup_philippine_retail_system_scheduled_2026-09-02_204043.sql.gz', '15146', 'scheduled', 'success', 'a3382f13a3361bb55f63bf85a25a20b041710fb6fdbf065b8e6fd250a5df4f1b', '34', '423', '0.042', '1', 'Automated recurring snapshot (interval: 60 mins)', '2026-09-02 20:40:43');

-- -----------------------------------------------------------------------------
-- Table structure for `bakery_batches`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `bakery_batches`;
CREATE TABLE `bakery_batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_code` varchar(50) NOT NULL,
  `product_id` int(11) NOT NULL,
  `premix_id` int(11) NOT NULL,
  `premix_used_kg` decimal(10,3) NOT NULL,
  `baked_quantity` int(11) NOT NULL,
  `baked_at` datetime NOT NULL DEFAULT current_timestamp(),
  `best_before` date DEFAULT NULL,
  `status` enum('planned','baked','waste') NOT NULL DEFAULT 'baked',
  `prepared_by` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_code` (`batch_code`),
  KEY `product_id` (`product_id`),
  KEY `premix_id` (`premix_id`),
  KEY `prepared_by` (`prepared_by`),
  CONSTRAINT `bakery_batches_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `bakery_batches_ibfk_2` FOREIGN KEY (`premix_id`) REFERENCES `premixes` (`id`),
  CONSTRAINT `bakery_batches_ibfk_3` FOREIGN KEY (`prepared_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `bakery_recipes`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `bakery_recipes`;
CREATE TABLE `bakery_recipes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `premix_id` int(11) NOT NULL,
  `premix_kg_per_batch` decimal(10,3) NOT NULL,
  `yield_per_batch` int(11) NOT NULL,
  `bake_minutes` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_product_premix` (`product_id`,`premix_id`),
  KEY `premix_id` (`premix_id`),
  CONSTRAINT `bakery_recipes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bakery_recipes_ibfk_2` FOREIGN KEY (`premix_id`) REFERENCES `premixes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `categories`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_category_name` (`name`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `categories` (22 records)
INSERT INTO `categories` (`id`, `parent_id`, `name`, `slug`, `icon`, `path`, `display_order`, `created_at`) VALUES
('1', NULL, 'Hardware', 'hardware', 'hardware', 'Hardware', '1', '2026-09-03 01:31:32'),
('2', '1', 'Locks & Security', 'locks-security', NULL, 'Hardware / Locks & Security', '1', '2026-09-03 01:31:32'),
('3', '2', 'Latches', 'latches', 'latches', 'Hardware / Locks & Security / Latches', '1', '2026-09-03 01:31:32'),
('4', '2', 'Padlocks', 'padlocks', 'padlocks', 'Hardware / Locks & Security / Padlocks', '2', '2026-09-03 01:31:32'),
('5', NULL, 'Electrical', 'electrical', 'electrical', 'Electrical', '2', '2026-09-03 01:31:32'),
('6', '5', 'Batteries', 'batteries', 'batteries', 'Electrical / Batteries', '1', '2026-09-03 01:31:32'),
('7', '5', 'Electrical Accessories', 'electrical-accessories', 'electrical-accessories', 'Electrical / Electrical Accessories', '2', '2026-09-03 01:31:32'),
('8', '5', 'Lighting', 'lighting', 'lighting', 'Electrical / Lighting', '3', '2026-09-03 01:31:32'),
('9', NULL, 'Household', 'household', 'household', 'Household', '3', '2026-09-03 01:31:32'),
('10', '9', 'Furnishings', 'furnishings', 'furnishings', 'Household / Furnishings', '1', '2026-09-03 01:31:32'),
('11', '9', 'Home Care', 'home-care', 'home-care', 'Household / Home Care', '2', '2026-09-03 01:31:32'),
('12', '9', 'Home Improvement', 'home-improvement', 'home-improvement', 'Household / Home Improvement', '3', '2026-09-03 01:31:32'),
('13', '9', 'Kitchen & Dining', 'kitchen-dining', 'kitchen-dining', 'Household / Kitchen & Dining', '4', '2026-09-03 01:31:32'),
('14', '9', 'Living & Bath', 'living-bath', 'living-bath', 'Household / Living & Bath', '5', '2026-09-03 01:31:32'),
('15', NULL, 'Stationery', 'stationery', 'stationery', 'Stationery', '4', '2026-09-03 01:31:32'),
('16', '15', 'Writing Instruments', 'writing-instruments', 'writing-instruments', 'Stationery / Writing Instruments', '1', '2026-09-03 01:31:32'),
('17', '15', 'Paper & Notebooks', 'paper-notebooks', 'paper-notebooks', 'Stationery / Paper & Notebooks', '2', '2026-09-03 01:31:32'),
('18', '15', 'Stationery Tools', 'stationery-tools', 'stationery-tools', 'Stationery / Stationery Tools', '3', '2026-09-03 01:31:32'),
('19', '15', 'Stationery Organisers', 'stationery-organisers', 'stationery-organisers', 'Stationery / Stationery Organisers', '4', '2026-09-03 01:31:32'),
('20', NULL, 'Toys', 'toys', 'toys', 'Toys', '5', '2026-09-03 01:31:32'),
('21', '20', 'Baby & Toddlers', 'baby-toddlers', 'baby-toddlers', 'Toys / Baby & Toddlers', '1', '2026-09-03 01:31:32'),
('22', '20', 'Kids Toys', 'kids-toys', 'kids-toys', 'Toys / Kids Toys', '2', '2026-09-03 01:31:32');

-- -----------------------------------------------------------------------------
-- Table structure for `customers`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `loyalty_points` int(11) NOT NULL DEFAULT 0,
  `membership_tier` enum('Regular','Bronze','Silver','Gold') NOT NULL DEFAULT 'Regular',
  `total_spent` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_code` (`customer_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `customers` (4 records)
INSERT INTO `customers` (`id`, `customer_code`, `name`, `phone`, `email`, `address`, `loyalty_points`, `membership_tier`, `total_spent`, `created_at`) VALUES
('1', 'CUST-1001', 'Juan Dela Cruz', '0917-123-4567', 'juan.delacruz@email.com', 'Quezon City', '322', 'Silver', '32725.00', '2026-08-20 14:32:53'),
('2', 'CUST-1002', 'Maria Santos', '0918-234-5678', 'maria.santos@email.com', 'Pasig City', '150', 'Bronze', '15200.00', '2026-08-20 14:32:53'),
('3', 'CUST-1003', 'Roberto Tan', '0920-345-6789', 'roberto.tan@email.com', 'Makati City', '650', 'Gold', '68400.00', '2026-08-20 14:32:53'),
('4', 'CUST-1004', 'Elena Reyes', '0922-456-7890', 'elena.reyes@email.com', 'Mandaluyong City', '45', 'Regular', '4500.00', '2026-08-20 14:32:53');

-- -----------------------------------------------------------------------------
-- Table structure for `email_verifications`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `email_verifications`;
CREATE TABLE `email_verifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_token` (`token`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `email_verifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `login_attempts`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `attempt_time` datetime NOT NULL DEFAULT current_timestamp(),
  `success` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_username` (`username`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_time` (`attempt_time`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `login_attempts` (55 records)
INSERT INTO `login_attempts` (`id`, `username`, `ip_address`, `attempt_time`, `success`) VALUES
('1', 'admin', '::1', '2026-08-14 23:44:06', '1'),
('2', 'admin', '::1', '2026-08-14 23:46:16', '1'),
('3', 'admin', '::1', '2026-08-14 23:56:03', '1'),
('4', 'admin', '::1', '2026-08-18 14:44:29', '0'),
('5', 'admin', '::1', '2026-08-18 14:44:40', '0'),
('6', 'admin', '::1', '2026-08-18 14:44:43', '0'),
('7', 'admin', '::1', '2026-08-18 14:45:06', '1'),
('8', 'admin', '::1', '2026-08-18 14:54:17', '1'),
('9', 'admin', '::1', '2026-08-18 15:03:38', '1'),
('10', 'admin', '::1', '2026-08-18 17:03:44', '1'),
('11', 'admin', '::1', '2026-08-18 17:04:00', '1'),
('12', 'admin', '::1', '2026-08-20 14:43:18', '1'),
('13', 'admin', '::1', '2026-08-21 00:40:14', '1'),
('14', 'admin', '::1', '2026-08-21 22:22:53', '1'),
('15', 'admin', '::1', '2026-08-21 22:38:21', '1'),
('16', 'admin', '::1', '2026-08-21 22:50:00', '1'),
('17', 'admin', '::1', '2026-08-21 22:51:33', '1'),
('18', 'admin', '::1', '2026-08-21 23:18:06', '1'),
('19', 'admin', '::1', '2026-08-22 01:12:34', '1'),
('20', 'admin', '::1', '2026-08-22 10:14:15', '1'),
('21', 'cashier1', '::1', '2026-08-22 10:15:19', '0'),
('22', 'cashier1', '::1', '2026-08-22 10:15:24', '0'),
('23', 'cashier', '::1', '2026-08-22 10:15:35', '0'),
('24', 'cashier', '::1', '2026-08-22 10:15:38', '0'),
('25', 'admin', '::1', '2026-08-22 10:15:52', '1'),
('26', 'cashier1', '::1', '2026-08-22 10:57:08', '1'),
('27', 'admin', '::1', '2026-08-22 11:00:21', '1'),
('28', 'cashier1', '::1', '2026-08-22 11:00:44', '0'),
('29', 'cashier1', '::1', '2026-08-22 11:00:53', '1'),
('30', 'admin', '::1', '2026-08-22 11:01:04', '1'),
('31', 'admin', '::1', '2026-08-22 11:02:51', '1'),
('32', 'cashier1', '::1', '2026-08-22 11:06:57', '1'),
('33', 'admin', '::1', '2026-08-22 11:09:56', '1'),
('34', 'cashier1', '::1', '2026-08-22 11:11:04', '1'),
('35', 'admin', '::1', '2026-08-22 11:11:18', '1'),
('36', 'cashier1', '::1', '2026-08-22 11:12:00', '1'),
('37', 'admin', '::1', '2026-08-22 11:12:14', '1'),
('38', 'cashier1', '::1', '2026-08-22 11:22:47', '1'),
('39', 'admin', '::1', '2026-08-22 11:32:27', '1'),
('40', 'admin', '::1', '2026-08-22 11:44:34', '1'),
('41', 'admin', '::1', '2026-08-22 14:03:36', '1'),
('42', 'admin', '::1', '2026-08-22 15:17:30', '1'),
('43', 'cashier1', '::1', '2026-08-22 15:35:58', '1'),
('44', 'cashier1', '::1', '2026-08-22 15:35:58', '1'),
('45', 'admin', '::1', '2026-08-22 15:36:24', '1'),
('46', 'admin', '::1', '2026-08-22 19:42:16', '1'),
('47', 'admin', '::1', '2026-08-22 19:46:14', '1'),
('48', 'admin', '::1', '2026-08-25 13:24:13', '1'),
('49', 'admin', '::1', '2026-09-02 23:10:09', '1'),
('50', 'admin', '::1', '2026-09-02 23:11:19', '1'),
('51', 'admin', '::1', '2026-09-02 23:55:15', '1'),
('52', 'admin', '::1', '2026-09-03 00:48:32', '1'),
('53', 'admin', '::1', '2026-09-03 00:55:54', '1'),
('54', 'cashier1', '::1', '2026-09-03 04:26:25', '1'),
('55', 'admin', '::1', '2026-09-03 04:26:51', '1');

-- -----------------------------------------------------------------------------
-- Table structure for `password_resets`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `otp_code` varchar(6) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_otp` (`otp_code`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `password_resets` (1 records)
INSERT INTO `password_resets` (`id`, `user_id`, `otp_code`, `expires_at`, `used`, `created_at`) VALUES
('5', '1', '365138', '2026-09-02 14:25:35', '0', '2026-09-02 20:20:35');

-- -----------------------------------------------------------------------------
-- Table structure for `permissions`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL DEFAULT 'General',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `permissions` (26 records)
INSERT INTO `permissions` (`id`, `name`, `display_name`, `category`, `description`, `created_at`) VALUES
('1', 'dashboard', 'View Dashboard', 'Core Access', 'Access role-specific dashboard and key performance summaries', '2026-08-14 23:16:56'),
('2', 'profile', 'Manage Profile', 'Core Access', 'View and update personal profile and security credentials', '2026-08-14 23:16:56'),
('3', 'users', 'User Management', 'Users & Security', 'View, create, edit, and deactivate user accounts', '2026-08-14 23:16:56'),
('4', 'manage_roles', 'Manage Roles & Permissions', 'Users & Security', 'Configure access control matrix, custom roles, and user overrides', '2026-08-14 23:16:56'),
('5', 'view_audit_logs', 'View Audit Trail', 'Users & Security', 'View security events, access logs, and modification history', '2026-08-14 23:16:56'),
('6', 'products', 'Product Management', 'Products & Categories', 'View product catalog and pricing', '2026-08-14 23:16:56'),
('7', 'add_edit_products', 'Add & Edit Products', 'Products & Categories', 'Create and update products, bakery recipes, and barcodes', '2026-08-14 23:16:56'),
('8', 'categories', 'Category Management', 'Products & Categories', 'Manage product categories and department groups', '2026-08-14 23:16:56'),
('9', 'inventory', 'Inventory Management', 'Inventory & Premix', 'View stock levels, ingredients, and batch movement tracking', '2026-08-14 23:16:56'),
('10', 'receive_stock', 'Receive Stock Deliveries', 'Inventory & Premix', 'Record incoming premix and ingredient shipments', '2026-08-14 23:16:56'),
('11', 'adjust_inventory', 'Adjust Inventory', 'Inventory & Premix', 'Perform stock reconciliations, waste logs, and count adjustments', '2026-08-14 23:16:56'),
('12', 'pos', 'Point of Sale (POS)', 'POS & Sales', 'Access the POS terminal register to input sales', '2026-08-14 23:16:56'),
('13', 'process_sale', 'Process Sales & Checkout', 'POS & Sales', 'Submit payment, finalize checkout, and record revenue', '2026-08-14 23:16:56'),
('14', 'transactions', 'Transaction History', 'POS & Sales', 'View historical sales receipts and customer transactions', '2026-08-14 23:16:56'),
('15', 'receipt', 'Print / View Receipts', 'POS & Sales', 'Reprint and inspect official sales receipts', '2026-08-14 23:16:56'),
('16', 'void_transactions', 'Void Transactions', 'POS & Sales', 'Void completed transactions with manager authorization', '2026-08-14 23:16:56'),
('17', 'apply_discounts', 'Apply Discounts', 'POS & Sales', 'Apply special order discounts and promotional rates', '2026-08-14 23:16:56'),
('18', 'approve_returns', 'Approve Product Returns', 'POS & Sales', 'Authorize customer product returns and exchange vouchers', '2026-08-14 23:16:56'),
('19', 'sales', 'Sales Overview', 'Reports & Finance', 'View aggregate sales analytics and operational metrics', '2026-08-14 23:16:56'),
('20', 'reports', 'Business Reports', 'Reports & Finance', 'Generate and export financial, inventory, and sales reports', '2026-08-14 23:16:56'),
('21', 'settings', 'System Settings', 'System Settings', 'Configure store metadata, tax rates, currency, and bakery policies', '2026-08-14 23:16:56'),
('22', 'suppliers', 'Manage Suppliers', 'Products & Catalog', 'View, add, and update supplier vendor records', '2026-08-20 14:34:13'),
('23', 'customers', 'Manage Customers', 'POS & Sales', 'Manage customer database and loyalty rewards membership', '2026-08-20 14:34:13'),
('24', 'stock_receiving', 'Stock Inward Receiving', 'Inventory Operations', 'Receive stock deliveries against supplier purchase orders', '2026-08-20 14:34:13'),
('25', 'stock_audit', 'Physical Stock Audit', 'Inventory Operations', 'Perform physical count reconciliation and log shrinkage/damage', '2026-08-20 14:34:13'),
('26', 'backup', 'Data Backup & Recovery', 'System Settings', 'Manage automated backups, execute disaster recovery restores, and check table integrity', '2026-08-26 19:33:49');

-- -----------------------------------------------------------------------------
-- Table structure for `premix_daily_controls`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `premix_daily_controls`;
CREATE TABLE `premix_daily_controls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `premix_id` int(11) NOT NULL,
  `control_date` date NOT NULL,
  `beginning_kg` decimal(10,3) NOT NULL DEFAULT 0.000,
  `delivery_kg` decimal(10,3) NOT NULL DEFAULT 0.000,
  `production_kg` decimal(10,3) NOT NULL DEFAULT 0.000,
  `actual_ending_kg` decimal(10,3) NOT NULL,
  `remarks` text DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_premix_control_day` (`premix_id`,`control_date`),
  KEY `recorded_by` (`recorded_by`),
  CONSTRAINT `premix_daily_controls_ibfk_1` FOREIGN KEY (`premix_id`) REFERENCES `premixes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `premix_daily_controls_ibfk_2` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `premix_daily_controls` (1 records)
INSERT INTO `premix_daily_controls` (`id`, `premix_id`, `control_date`, `beginning_kg`, `delivery_kg`, `production_kg`, `actual_ending_kg`, `remarks`, `recorded_by`, `recorded_at`) VALUES
('1', '1', '2026-08-18', '0.000', '0.000', '0.000', '0.000', '', '1', '2026-08-18 15:42:17');

-- -----------------------------------------------------------------------------
-- Table structure for `premix_movements`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `premix_movements`;
CREATE TABLE `premix_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `premix_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `movement_type` enum('receive','bake_use','adjustment','waste') NOT NULL,
  `quantity_kg` decimal(10,3) NOT NULL,
  `reference_no` varchar(80) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `premix_id` (`premix_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `premix_movements_ibfk_1` FOREIGN KEY (`premix_id`) REFERENCES `premixes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `premix_movements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `premixes`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `premixes`;
CREATE TABLE `premixes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `sku` varchar(50) NOT NULL,
  `supplier` varchar(150) DEFAULT NULL,
  `stock_kg` decimal(10,3) NOT NULL DEFAULT 0.000,
  `reorder_level_kg` decimal(10,3) NOT NULL DEFAULT 0.000,
  `cost_per_kg` decimal(10,2) NOT NULL DEFAULT 0.00,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `premixes` (49 records)
INSERT INTO `premixes` (`id`, `name`, `sku`, `supplier`, `stock_kg`, `reorder_level_kg`, `cost_per_kg`, `active`, `created_at`) VALUES
('1', 'Banana Loaf/Slice', 'PMX-001', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('2', 'Binangkal', 'PMX-002', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('3', 'Butter Stresussel', 'PMX-003', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('4', 'Chesse Ballls', 'PMX-004', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('5', 'Cheese Bread', 'PMX-005', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('6', 'Chees Loaf (2kg)', 'PMX-006', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('7', 'Cheese Roll', 'PMX-007', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('8', 'Cheesemelt', 'PMX-008', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('9', 'Choco Balls', 'PMX-009', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('10', 'Choco Krinkles(1.2g)', 'PMX-010', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('11', 'Cinnamon Roll', 'PMX-011', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('12', 'Glassie(2kg)', 'PMX-012', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('13', 'Cracked Pandesal', 'PMX-013', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('14', 'Eggroll', 'PMX-014', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('15', 'Ensaymada', 'PMX-015', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('16', 'Francis', 'PMX-016', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('17', 'Garlic Bread', 'PMX-017', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('18', 'Halfmoon', 'PMX-018', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('19', 'Hopia', 'PMX-019', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('20', 'King Roll', 'PMX-020', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('21', 'Monay', 'PMX-021', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('22', 'Pancho', 'PMX-022', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('23', 'Pande Leche', 'PMX-023', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('24', 'Pandeciosa', 'PMX-024', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('25', 'Pandesal B1T1', 'PMX-025', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('26', 'Pandesal - 5', 'PMX-026', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('27', 'Polvoron Cookies', 'PMX-027', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('28', 'Premium(2kg)', 'PMX-028', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('29', 'Red Pie(1kg)', 'PMX-029', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('30', 'Siakoy', 'PMX-030', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('31', 'Spanish', 'PMX-031', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('32', 'Star Bread', 'PMX-032', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('33', 'Torta Special', 'PMX-033', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('34', 'Wheat Pandesal', 'PMX-034', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('35', 'Wheat Loaf', 'PMX-035', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('36', 'Choco German', 'PMX-036', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('37', 'Fig Bun', 'PMX-037', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('38', 'Coffee Bun', 'PMX-038', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('39', 'Nutri Bun', 'PMX-039', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('40', 'Pande-Coco', 'PMX-040', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('41', 'Butchi-Coco', 'PMX-041', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('42', 'Coco Bun', 'PMX-042', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('43', 'Malunggay Bun', 'PMX-043', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('44', 'Malunggay Cheese Pandesal', 'PMX-044', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('45', 'Ube Bread', 'PMX-045', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('46', 'Mini Cinnamon', 'PMX-046', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('47', 'Kababayan', 'PMX-047', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('48', 'PIneapple Pie', 'PMX-048', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16'),
('49', 'Spansish Overload', 'PMX-049', NULL, '0.000', '0.000', '0.00', '1', '2026-08-14 22:58:16');

-- -----------------------------------------------------------------------------
-- Table structure for `product_images`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `products`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(50) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `cost_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `stock` int(11) NOT NULL DEFAULT 0,
  `barcode` varchar(50) DEFAULT NULL,
  `item_type` varchar(50) NOT NULL DEFAULT 'retail_item',
  `unit` varchar(30) NOT NULL DEFAULT 'piece',
  `reorder_level` decimal(10,2) NOT NULL DEFAULT 10.00,
  `shelf_life_days` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `image` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `barcode` (`barcode`),
  UNIQUE KEY `sku` (`sku`),
  KEY `category_id` (`category_id`),
  KEY `fk_products_supplier` (`supplier_id`),
  CONSTRAINT `fk_products_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `products` (103 records)
INSERT INTO `products` (`id`, `sku`, `name`, `brand`, `category_id`, `supplier_id`, `price`, `cost_price`, `stock`, `barcode`, `item_type`, `unit`, `reorder_level`, `shelf_life_days`, `is_active`, `image`, `image_path`, `created_at`) VALUES
('63', 'SKU-ELE-026', 'Electric Desk Fan 12-inch', 'Triple8 Retail', '7', NULL, '599.00', '419.30', '36', '480888000026', 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_63_1788368505.jpg', 'uploads/products/prod_63_1788368505.jpg', '2026-08-22 00:28:10'),
('69', 'SKU-WIR-032', 'Wired In-Ear Earphones 3.5mm', 'Triple8 Retail', '7', NULL, '110.00', '77.00', '54', '480888000032', 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_69_1788368563.jpg', 'uploads/products/prod_69_1788368563.jpg', '2026-08-22 00:28:10'),
('72', 'SKU-AAR-035', 'Eveready AA Battery', 'Triple8 Retail', '6', NULL, '280.00', '196.00', '119', '480888000035', 'retail_item', 'pc', '30.00', NULL, '1', 'uploads/products/prod_72_1788367923.jpg', 'uploads/products/prod_72_1788367923.jpg', '2026-08-22 00:28:10'),
('80', 'SKU-BUI-043', 'Building Blocks Toy Set', 'Triple8 Retail', '22', NULL, '299.00', '209.30', '63', '480888000043', 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_80_1788368232.jpg', 'uploads/products/prod_80_1788368232.jpg', '2026-08-22 00:28:10'),
('91', 'SKU-CYL-897', 'Cylindrical Door Knob 587AB', 'Retail', '2', NULL, '15.00', '10.50', '37', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_91_1788371607.jpg', 'uploads/products/prod_91_1788371607.jpg', '2026-09-03 01:38:56'),
('92', 'SKU-ATY-718', 'A-Type Door Handle', 'Retail', '2', NULL, '15.00', '10.50', '54', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_92_1788371566.jpg', 'uploads/products/prod_92_1788371566.jpg', '2026-09-03 01:41:53'),
('94', 'SKU-STA-961', 'Stainless Steel Hasp', 'Retail', '3', NULL, '69.00', '48.30', '75', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_94_1788371899.png', 'uploads/products/prod_94_1788371899.png', '2026-09-03 01:46:31'),
('95', 'SKU-DOO-861', 'Door Barrel Bolt 4 inch', 'Retail', '3', NULL, '46.00', '32.20', '101', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_95_1788371695.jpg', 'uploads/products/prod_95_1788371695.jpg', '2026-09-03 01:48:25'),
('96', 'SKU-STA-638', 'Stainless Steel Door Hinges (3.5\")', 'Retail', '3', NULL, '67.00', '46.90', '78', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_96_1788371804.png', 'uploads/products/prod_96_1788371804.png', '2026-09-03 01:50:06'),
('97', 'SKU-PAD-253', 'Padlock - Long Shackle 30mm', 'Retail', '4', NULL, '100.00', '70.00', '64', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_97_1788371978.jpg', 'uploads/products/prod_97_1788371978.jpg', '2026-09-03 01:59:38'),
('98', 'SKU-BRA-974', 'Brass Padlock (38mm)', 'Retail', '4', NULL, '77.00', '53.90', '50', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_98_1788372060.jpg', 'uploads/products/prod_98_1788372060.jpg', '2026-09-03 02:01:00'),
('99', 'SKU-IRO-569', 'Iron Padlock 50mm ST-P6150', 'Retail', '4', NULL, '16.00', '11.20', '45', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_99_1788372135.jpg', 'uploads/products/prod_99_1788372135.jpg', '2026-09-03 02:02:15'),
('100', 'SKU-PAD-239', 'Pad Lock (50mm)', 'Retail', '4', NULL, '143.00', '100.10', '59', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_100_1788372232.jpg', 'uploads/products/prod_100_1788372232.jpg', '2026-09-03 02:03:52'),
('101', 'SKU-ENE-460', 'ENERGIZER Max Power Seal Alkaline Battery AAA (8pcs)', 'Retail', '6', NULL, '403.00', '282.10', '108', NULL, 'retail_item', 'pc', '30.00', NULL, '1', 'uploads/products/prod_101_1788372351.jpg', 'uploads/products/prod_101_1788372351.jpg', '2026-09-03 02:05:51'),
('102', 'SKU-ENE-165', 'ENERGIZER Max Alkaline Battery 9V', 'Retail', '6', NULL, '224.00', '156.80', '177', NULL, 'retail_item', 'pc', '30.00', NULL, '1', 'uploads/products/prod_102_1788372435.jpg', 'uploads/products/prod_102_1788372435.jpg', '2026-09-03 02:07:15'),
('103', 'SKU-PHI-114', 'PHILIPS Essential 3U Shape LED Bulb Cool Daylight 18W', 'Retail', '8', NULL, '245.00', '171.50', '70', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_103_1788372631.jpg', 'uploads/products/prod_103_1788372631.jpg', '2026-09-03 02:10:31'),
('104', 'SKU-LED-106', 'LED A60 Bulb Daylight E27 (11W)', 'Retail', '8', NULL, '69.00', '48.30', '80', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_104_1788372936.webp', 'uploads/products/prod_104_1788372936.webp', '2026-09-03 02:15:36'),
('105', 'SKU-LED-810', 'LED A60 Bulb Warm White E27 (7W)', 'Retail', '8', NULL, '47.00', '32.90', '92', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_105_1788372982.webp', 'uploads/products/prod_105_1788372982.webp', '2026-09-03 02:16:22'),
('106', 'SKU-TLE-736', 'T50 LED Bulb Daylight E27 (8W)', 'Retail', '8', NULL, '77.00', '53.90', '72', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_106_1788373117.webp', 'uploads/products/prod_106_1788373117.webp', '2026-09-03 02:18:37'),
('107', 'SKU-FLA-392', 'Flashlight', 'Retail', '8', NULL, '122.00', '85.40', '61', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_107_1788373233.webp', 'uploads/products/prod_107_1788373233.webp', '2026-09-03 02:20:33'),
('108', 'SKU-QUA-394', 'QUARTZ Wall Clock XD847', 'Retail', '10', NULL, '152.00', '106.40', '74', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_108_1788373446.webp', 'uploads/products/prod_108_1788373446.webp', '2026-09-03 02:24:06'),
('109', 'SKU-MIN-281', 'Minimalist Circle Wall Clock', 'Retail', '10', NULL, '152.00', '106.40', '72', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_109_1788373586.webp', 'uploads/products/prod_109_1788373586.webp', '2026-09-03 02:26:26'),
('110', 'SKU-LCD-318', 'LCD Digital Alarm Clock (14cm x 8cm)', 'Retail', '10', NULL, '369.00', '258.30', '43', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_110_1788373705.webp', 'uploads/products/prod_110_1788373705.webp', '2026-09-03 02:28:25'),
('111', 'SKU-CIR-159', 'Circular Minimalistic Wall Clock WSH-0440-12', 'Retail', '10', NULL, '338.00', '236.60', '77', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_111_1788373894.webp', 'uploads/products/prod_111_1788373894.webp', '2026-09-03 02:31:34'),
('112', 'SKU-PRE-477', 'Premium Anti Slip Mat 853 (45x100cm)', 'Retail', '10', NULL, '83.00', '58.10', '44', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_112_1788374068.webp', 'uploads/products/prod_112_1788374068.webp', '2026-09-03 02:34:28'),
('113', 'SKU-BAT-296', 'Bathroom Protection Bathmat (68cmx39cm)', 'Retail', '10', NULL, '152.00', '106.40', '56', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_113_1788374168.webp', 'uploads/products/prod_113_1788374168.webp', '2026-09-03 02:36:08'),
('114', 'SKU-DIS-935', 'Disney Minnie Metal Pail (11cm x 10cm)', 'Retail', '10', NULL, '137.00', '95.90', '42', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_114_1788374237.webp', 'uploads/products/prod_114_1788374237.webp', '2026-09-03 02:37:17'),
('115', 'SKU-DEC-841', 'Decorative Artificial Plant YJ-125', 'Retail', '10', NULL, '77.00', '53.90', '29', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_115_1788374288.webp', 'uploads/products/prod_115_1788374288.webp', '2026-09-03 02:38:08'),
('116', 'SKU-DIS-770', 'Disney Mickey Metal Pail (15cm x 15cm)', 'Retail', '10', NULL, '9.00', '6.30', '43', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_116_1788374353.webp', 'uploads/products/prod_116_1788374353.webp', '2026-09-03 02:39:13'),
('117', 'SKU-DIS-648', 'Disney Frozen Metal Pail (11cm x 10cm)', 'Retail', '10', NULL, '5.00', '3.50', '55', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_117_1788374388.webp', 'uploads/products/prod_117_1788374388.webp', '2026-09-03 02:39:48'),
('118', 'SKU-WOO-758', 'Wood Pattern A3 Size Photo Frame (46 cm x 33 cm)- Wedding/ Family/ Certificate', 'Retail', '10', NULL, '38.00', '26.60', '51', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_118_1788374492.png', 'uploads/products/prod_118_1788374492.png', '2026-09-03 02:41:32'),
('119', 'SKU-COL-327', 'Colorful Rainbow Umbrella', 'Retail', '10', NULL, '321.00', '224.70', '59', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_119_1788374553.png', 'uploads/products/prod_119_1788374553.png', '2026-09-03 02:42:33'),
('120', 'SKU-WIN-733', 'Windproof Umbrella (85cm)', 'Retail', '10', NULL, '207.00', '144.90', '29', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_120_1788374639.png', 'uploads/products/prod_120_1788374639.png', '2026-09-03 02:43:59'),
('121', 'SKU-LAR-156', 'Large Automatic Portable Umbrella', 'Retail', '10', NULL, '400.00', '280.00', '32', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_121_1788374688.png', 'uploads/products/prod_121_1788374688.png', '2026-09-03 02:44:48'),
('122', 'SKU-GEL-736', 'Gel Air Freshener Lavender Scent (160g)', 'Retail', '11', NULL, '3.00', '2.10', '80', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_122_1788374757.png', 'uploads/products/prod_122_1788374757.png', '2026-09-03 02:45:57'),
('123', 'SKU-HAN-908', 'Hanging Air Freshener Lemon - 2pcs', 'Retail', '11', NULL, '28.00', '19.60', '111', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_123_1788374837.webp', 'uploads/products/prod_123_1788374837.webp', '2026-09-03 02:47:17'),
('124', 'SKU-ZEN-647', 'ZENXIN Garbage Bag Bonus Pack (3 Rolls) - Small Size', 'Retail', '11', NULL, '101.00', '70.70', '93', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_124_1788374914.webp', 'uploads/products/prod_124_1788374914.webp', '2026-09-03 02:48:34'),
('125', 'SKU-MUL-584', 'Multipurpose Microfiber Cloth (2pcs)', 'Retail', '11', NULL, '37.00', '25.90', '64', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_125_1788375038.webp', 'uploads/products/prod_125_1788375038.webp', '2026-09-03 02:50:38'),
('126', 'SKU-BRO-865', 'Broom and Dustpan Set Cleaning', 'Retail', '11', NULL, '118.00', '82.60', '83', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_126_1788375095.png', 'uploads/products/prod_126_1788375095.png', '2026-09-03 02:51:35'),
('127', 'SKU-MIC-410', 'Microfiber Flat Mop', 'Retail', '11', NULL, '431.00', '301.70', '59', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_127_1788375156.png', 'uploads/products/prod_127_1788375156.png', '2026-09-03 02:52:36'),
('128', 'SKU-STA-466', 'Stainless Steel Scrubber Scouring Ball', 'Retail', '11', NULL, '15.00', '10.50', '113', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_128_1788375232.png', 'uploads/products/prod_128_1788375232.png', '2026-09-03 02:53:52'),
('129', 'SKU-CLE-936', 'Cleaning Dual-Sided Scouring Sponge', 'Retail', '11', NULL, '84.00', '58.80', '68', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_129_1788375302.png', 'uploads/products/prod_129_1788375302.png', '2026-09-03 02:55:02'),
('130', 'SKU-BAY-278', 'BAYGON Cockroach Control', 'Retail', '11', NULL, '248.00', '173.60', '55', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_130_1788375379.webp', 'uploads/products/prod_130_1788375379.webp', '2026-09-03 02:56:19'),
('131', 'SKU-USB-628', 'Usb Mosquito Racket', 'Retail', '11', NULL, '203.00', '142.10', '111', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_131_1788375438.webp', 'uploads/products/prod_131_1788375438.webp', '2026-09-03 02:57:18'),
('132', 'SKU-BUD-407', 'Budget Toilet Roll Tissue', 'Retail', '11', NULL, '20.00', '14.00', '73', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_132_1788375501.png', 'uploads/products/prod_132_1788375501.png', '2026-09-03 02:58:21'),
('133', 'SKU-DOU-918', 'Double Handle Rattan Basket (28cm X 16cm)', 'Retail', '12', NULL, '139.00', '97.30', '52', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_133_1788375749.webp', 'uploads/products/prod_133_1788375749.webp', '2026-09-03 03:02:29'),
('134', 'SKU-SFR-655', 'S-FRONT Dazzle Colour Plastic Hangers (6pcs)', 'Retail', '12', NULL, '103.00', '72.10', '79', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_134_1788375807.webp', 'uploads/products/prod_134_1788375807.webp', '2026-09-03 03:03:27'),
('135', 'SKU-ROT-562', 'Rotating Head Hanger (5pc)', 'Retail', '12', NULL, '109.00', '76.30', '59', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_135_1788375859.webp', 'uploads/products/prod_135_1788375859.webp', '2026-09-03 03:04:19'),
('136', 'SKU-FAM-406', 'Family Metal Coated Clothes Hanger HP92-054 (8pcs)', 'Retail', '12', NULL, '64.00', '44.80', '83', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_136_1788375914.webp', 'uploads/products/prod_136_1788375914.webp', '2026-09-03 03:05:14'),
('137', 'SKU-HIG-465', 'High Quality 4 Tier Plastic Shoe Shelf 1620', 'Retail', '12', NULL, '346.00', '242.20', '41', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_137_1788375999.webp', 'uploads/products/prod_137_1788375999.webp', '2026-09-03 03:06:39'),
('138', 'SKU-SAF-975', 'Safety Pins (60 pcs)', 'Retail', '18', NULL, '15.00', '10.50', '38', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_138_1788376080.webp', 'uploads/products/prod_138_1788376080.webp', '2026-09-03 03:08:00'),
('139', 'SKU-OVE-355', 'Oven Glove (32cm)', 'Retail', '13', NULL, '77.00', '53.90', '43', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_139_1788376167.png', 'uploads/products/prod_139_1788376167.png', '2026-09-03 03:09:27'),
('140', 'SKU-PLA-233', 'Plastic Measuring Cups', 'Retail', '13', NULL, '81.00', '56.70', '61', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_140_1788376225.png', 'uploads/products/prod_140_1788376225.png', '2026-09-03 03:10:25'),
('141', 'SKU-MEC-943', 'Mechanical Kitchen Scale', 'Retail', '13', NULL, '431.00', '301.70', '28', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_141_1788376299.webp', 'uploads/products/prod_141_1788376299.webp', '2026-09-03 03:11:39'),
('142', 'SKU-WAT-621', 'Water Bottle (2.8L)', 'Retail', '13', NULL, '338.00', '236.60', '75', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_142_1788376388.webp', 'uploads/products/prod_142_1788376388.webp', '2026-09-03 03:13:08'),
('143', 'SKU-LAR-758', 'Large Food Container', 'Retail', '13', NULL, '106.00', '74.20', '69', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_143_1788376513.png', 'uploads/products/prod_143_1788376513.png', '2026-09-03 03:15:13'),
('144', 'SKU-STA-767', 'Stainless Steel Spoon 10 PCS', 'Retail', '13', NULL, '54.00', '37.80', '67', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_144_1788376575.webp', 'uploads/products/prod_144_1788376575.webp', '2026-09-03 03:16:15'),
('145', 'SKU-STA-820', 'Stainless-Steel Table Fork', 'Retail', '13', NULL, '152.00', '106.40', '134', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_145_1788376626.webp', 'uploads/products/prod_145_1788376626.webp', '2026-09-03 03:17:06'),
('146', 'SKU-ALU-417', 'Aluminium Non-Stick Fry Pan', 'Retail', '13', NULL, '370.00', '259.00', '33', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_146_1788376701.webp', 'uploads/products/prod_146_1788376701.webp', '2026-09-03 03:18:21'),
('147', 'SKU-FOO-677', 'Footed Colander', 'Retail', '13', NULL, '115.00', '80.50', '55', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_147_1788376762.webp', 'uploads/products/prod_147_1788376762.webp', '2026-09-03 03:19:22'),
('148', 'SKU-NON-656', 'Non Stick Frying Pan', 'Retail', '13', NULL, '273.00', '191.10', '42', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_148_1788376821.webp', 'uploads/products/prod_148_1788376821.webp', '2026-09-03 03:20:21'),
('149', 'SKU-PLA-946', 'Plastic Jug', 'Retail', '13', NULL, '122.00', '85.40', '47', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_149_1788376868.webp', 'uploads/products/prod_149_1788376868.webp', '2026-09-03 03:21:08'),
('150', 'SKU-DUR-458', 'Durable Plastic Jar Container', 'Retail', '13', NULL, '47.00', '32.90', '48', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_150_1788376916.webp', 'uploads/products/prod_150_1788376916.webp', '2026-09-03 03:21:56'),
('151', 'SKU-MUL-807', 'Multipurpose Container', 'Retail', '13', NULL, '77.00', '53.90', '72', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_151_1788376951.webp', 'uploads/products/prod_151_1788376951.webp', '2026-09-03 03:22:31'),
('152', 'SKU-MUL-693', 'Multipurpose Food Container', 'Retail', '13', NULL, '122.00', '85.40', '37', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_152_1788376996.webp', 'uploads/products/prod_152_1788376996.webp', '2026-09-03 03:23:16'),
('153', 'SKU-PLA-118', 'Plastic Transparent Storage Stackable Container', 'Retail', '13', NULL, '276.00', '193.20', '63', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_153_1788377052.webp', 'uploads/products/prod_153_1788377052.webp', '2026-09-03 03:24:12'),
('154', 'SKU-PAP-109', 'Paper Plate 9 Inch', 'Retail', '13', NULL, '81.00', '56.70', '96', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_154_1788377145.png', 'uploads/products/prod_154_1788377145.png', '2026-09-03 03:25:45'),
('155', 'SKU-GLA-336', 'Glass Jug with Cups Set', 'Retail', '13', NULL, '230.00', '161.00', '46', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_155_1788377198.png', 'uploads/products/prod_155_1788377198.png', '2026-09-03 03:26:38'),
('156', 'SKU-STA-716', 'Stainless Steel Oil Strainer', 'Retail', '13', NULL, '97.00', '67.90', '45', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_156_1788377293.webp', 'uploads/products/prod_156_1788377293.webp', '2026-09-03 03:28:13'),
('157', 'SKU-PLA-597', 'Plastic Cutting Board White', 'Retail', '13', NULL, '152.00', '106.40', '71', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_157_1788377363.webp', 'uploads/products/prod_157_1788377363.webp', '2026-09-03 03:29:23'),
('158', 'SKU-BAM-980', 'Bamboo Cutting Board', 'Retail', '13', NULL, '151.00', '105.70', '54', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_158_1788377410.webp', 'uploads/products/prod_158_1788377410.webp', '2026-09-03 03:30:10'),
('159', 'SKU-TWI-842', 'Twin Blade Razor', 'Retail', '14', NULL, '35.00', '24.50', '35', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_159_1788377501.webp', 'uploads/products/prod_159_1788377501.webp', '2026-09-03 03:31:41'),
('160', 'SKU-FEA-599', 'Feather Pillow', 'Retail', '14', NULL, '154.00', '107.80', '40', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_160_1788377580.webp', 'uploads/products/prod_160_1788377580.webp', '2026-09-03 03:33:00'),
('161', 'SKU-MIC-518', 'Microfiber Multi-Colour Square Towels', 'Retail', '14', NULL, '116.00', '81.20', '52', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_161_1788377631.webp', 'uploads/products/prod_161_1788377631.webp', '2026-09-03 03:33:51'),
('162', 'SKU-TER-130', 'Terry cloth Bath Towel', 'Retail', '14', NULL, '246.00', '172.20', '30', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_162_1788377680.webp', 'uploads/products/prod_162_1788377680.webp', '2026-09-03 03:34:40'),
('163', 'SKU-PAI-342', 'Pail 4 Gallon', 'Retail', '14', NULL, '90.00', '63.00', '61', NULL, 'retail_item', 'pc', '12.00', NULL, '1', 'uploads/products/prod_163_1788377767.webp', 'uploads/products/prod_163_1788377767.webp', '2026-09-03 03:36:07'),
('164', 'SKU-BLA-269', 'Black Gel Ink Pen', 'Retail', '16', NULL, '10.00', '7.00', '222', NULL, 'retail_item', 'pc', '30.00', NULL, '1', 'uploads/products/prod_164_1788378039.png', 'uploads/products/prod_164_1788378039.png', '2026-09-03 03:40:39'),
('165', 'SKU-HIG-348', 'Highlighter Marker', 'Retail', '16', NULL, '57.00', '39.90', '189', NULL, 'retail_item', 'pc', '30.00', NULL, '1', 'uploads/products/prod_165_1788378110.webp', 'uploads/products/prod_165_1788378110.webp', '2026-09-03 03:41:50'),
('166', 'SKU-HIT-149', 'hite Dust-Free Eraser', 'Retail', '16', NULL, '10.00', '7.00', '150', NULL, 'retail_item', 'pc', '30.00', NULL, '1', 'uploads/products/prod_166_1788378189.webp', 'uploads/products/prod_166_1788378189.webp', '2026-09-03 03:43:09'),
('167', 'SKU-COR-893', 'Correction Tape', 'Retail', '16', NULL, '15.00', '10.50', '179', NULL, 'retail_item', 'pc', '30.00', NULL, '1', 'uploads/products/prod_167_1788378233.webp', 'uploads/products/prod_167_1788378233.webp', '2026-09-03 03:43:53'),
('168', 'SKU-NOT-908', 'Notebook', 'Retail', '17', NULL, '152.00', '106.40', '123', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_168_1788378401.png', 'uploads/products/prod_168_1788378401.png', '2026-09-03 03:46:41'),
('169', 'SKU-COL-985', 'Colour A4 Construction Paper', 'Retail', '17', NULL, '106.00', '74.20', '142', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_169_1788378476.webp', 'uploads/products/prod_169_1788378476.webp', '2026-09-03 03:47:56'),
('170', 'SKU-COL-357', 'Colorful Sticky Notes', 'Retail', '17', NULL, '54.00', '37.80', '90', NULL, 'retail_item', 'pc', '20.00', NULL, '1', 'uploads/products/prod_170_1788378600.png', 'uploads/products/prod_170_1788378600.png', '2026-09-03 03:50:00'),
('171', 'SKU-STA-151', 'Stainless-Steel Scissors', 'Retail', '18', NULL, '47.00', '32.90', '50', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_171_1788378662.webp', 'uploads/products/prod_171_1788378662.webp', '2026-09-03 03:51:02'),
('172', 'SKU-STA-670', 'Stapler With Bullet', 'Retail', '18', NULL, '84.00', '58.80', '58', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_172_1788378738.webp', 'uploads/products/prod_172_1788378738.webp', '2026-09-03 03:52:18'),
('173', 'SKU-TRA-471', 'Transparent Tape', 'Retail', '18', NULL, '183.00', '128.10', '53', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_173_1788378813.webp', 'uploads/products/prod_173_1788378813.webp', '2026-09-03 03:53:33'),
('174', 'SKU-DOU-516', 'Double Sided Tape', 'Retail', '18', NULL, '15.00', '10.50', '41', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_174_1788378880.png', 'uploads/products/prod_174_1788378880.png', '2026-09-03 03:54:40'),
('175', 'SKU-TRA-738', 'Transparent Plastic Ruler', 'Retail', '18', NULL, '15.00', '10.50', '62', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_175_1788378954.webp', 'uploads/products/prod_175_1788378954.webp', '2026-09-03 03:55:54'),
('176', 'SKU-MET-223', 'Metal Ruler', 'Retail', '18', NULL, '15.00', '10.50', '39', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_176_1788378989.webp', 'uploads/products/prod_176_1788378989.webp', '2026-09-03 03:56:29'),
('177', 'SKU-SCI-181', 'Scientific Calculator', 'Retail', '18', NULL, '152.00', '106.40', '45', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_177_1788379050.webp', 'uploads/products/prod_177_1788379050.webp', '2026-09-03 03:57:30'),
('178', 'SKU-CAL-689', 'Calculator', 'Retail', '18', NULL, '154.00', '107.80', '55', NULL, 'retail_item', 'pc', '15.00', NULL, '1', 'uploads/products/prod_178_1788379105.webp', 'uploads/products/prod_178_1788379105.webp', '2026-09-03 03:58:25'),
('179', 'SKU-COL-255', 'Color Binder Clips (40 pieces)', 'Retail', '19', NULL, '109.00', '76.30', '99', NULL, 'retail_item', 'pc', '25.00', NULL, '1', 'uploads/products/prod_179_1788379167.webp', 'uploads/products/prod_179_1788379167.webp', '2026-09-03 03:59:27'),
('180', 'SKU-TWO-281', 'Two-Hole Punch', 'Retail', '19', NULL, '106.00', '74.20', '179', NULL, 'retail_item', 'pc', '25.00', NULL, '1', 'uploads/products/prod_180_1788379209.webp', 'uploads/products/prod_180_1788379209.webp', '2026-09-03 04:00:09'),
('181', 'SKU-PAP-977', 'Paper Clip (100 pieces)', 'Retail', '19', NULL, '203.00', '142.10', '131', NULL, 'retail_item', 'pc', '25.00', NULL, '1', 'uploads/products/prod_181_1788379259.webp', 'uploads/products/prod_181_1788379259.webp', '2026-09-03 04:00:59'),
('182', 'SKU-PLA-127', 'Plastic Fasterner', 'Retail', '19', NULL, '15.00', '10.50', '178', NULL, 'retail_item', 'pc', '25.00', NULL, '1', 'uploads/products/prod_182_1788379316.webp', 'uploads/products/prod_182_1788379316.webp', '2026-09-03 04:01:56'),
('183', 'SKU-TRA-337', 'Transparent Folder', 'Retail', '19', NULL, '20.00', '14.00', '119', NULL, 'retail_item', 'pc', '25.00', NULL, '1', 'uploads/products/prod_183_1788379389.webp', 'uploads/products/prod_183_1788379389.webp', '2026-09-03 04:03:09'),
('184', 'SKU-BAB-188', 'Baby Ball Rattle Toy', 'Retail', '21', NULL, '91.00', '63.70', '33', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_184_1788379513.png', 'uploads/products/prod_184_1788379513.png', '2026-09-03 04:05:13'),
('185', 'SKU-WIL-192', 'Wild Animal Toys', 'Retail', '22', NULL, '215.00', '150.50', '42', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_185_1788379585.png', 'uploads/products/prod_185_1788379585.png', '2026-09-03 04:06:25'),
('186', 'SKU-SUP-736', 'Super Sport Racing Set Car Toy', 'Retail', '22', NULL, '346.00', '242.20', '35', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_186_1788379677.png', 'uploads/products/prod_186_1788379677.png', '2026-09-03 04:07:57'),
('187', 'SKU-FAS-562', 'Fast Push Game', 'Retail', '22', NULL, '254.00', '177.80', '59', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_187_1788379776.png', 'uploads/products/prod_187_1788379776.png', '2026-09-03 04:09:36');
INSERT INTO `products` (`id`, `sku`, `name`, `brand`, `category_id`, `supplier_id`, `price`, `cost_price`, `stock`, `barcode`, `item_type`, `unit`, `reorder_level`, `shelf_life_days`, `is_active`, `image`, `image_path`, `created_at`) VALUES
('188', 'SKU-FAM-881', 'Family Dessert Play Set', 'Retail', '22', NULL, '143.00', '100.10', '36', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_188_1788379825.png', 'uploads/products/prod_188_1788379825.png', '2026-09-03 04:10:25'),
('189', 'SKU-POL-670', 'Police Playset Toys', 'Retail', '22', NULL, '152.00', '106.40', '41', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_189_1788379869.webp', 'uploads/products/prod_189_1788379869.webp', '2026-09-03 04:11:09'),
('190', 'SKU-PLU-754', 'Plush Toy', 'Retail', '22', NULL, '540.00', '378.00', '46', NULL, 'retail_item', 'pc', '10.00', NULL, '1', 'uploads/products/prod_190_1788379930.png', 'uploads/products/prod_190_1788379930.png', '2026-09-03 04:12:10');

-- -----------------------------------------------------------------------------
-- Table structure for `profile_settings`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `profile_settings`;
CREATE TABLE `profile_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `setting_name` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_setting` (`user_id`,`setting_name`),
  CONSTRAINT `profile_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `profile_settings` (3 records)
INSERT INTO `profile_settings` (`id`, `user_id`, `setting_name`, `setting_value`, `created_at`, `updated_at`) VALUES
('1', '1', 'email_notifications', '1', '2026-03-17 23:23:05', '2026-03-17 23:23:05'),
('2', '1', 'theme', 'light', '2026-03-17 23:23:05', '2026-03-17 23:23:05'),
('3', '1', 'language', 'en', '2026-03-17 23:23:05', '2026-03-17 23:23:05');

-- -----------------------------------------------------------------------------
-- Table structure for `purchase_order_items`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `purchase_order_items`;
CREATE TABLE `purchase_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_cost` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `po_id` (`po_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`po_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `purchase_orders`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `purchase_orders`;
CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_number` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `reference_invoice` varchar(80) DEFAULT NULL,
  `total_cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','received','cancelled') NOT NULL DEFAULT 'received',
  `received_by` int(11) DEFAULT NULL,
  `received_at` datetime DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_number` (`po_number`),
  KEY `supplier_id` (`supplier_id`),
  KEY `received_by` (`received_by`),
  CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `purchase_orders_ibfk_2` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `purchase_orders` (2 records)
INSERT INTO `purchase_orders` (`id`, `po_number`, `supplier_id`, `reference_invoice`, `total_cost`, `status`, `received_by`, `received_at`, `notes`, `created_at`) VALUES
('1', 'PO-2026-001', '1', 'URC-INV-88901', '12450.00', 'received', '1', '2026-08-17 14:34:13', 'Weekly beverage & snack replenishment', '2026-08-20 14:34:13'),
('2', 'PO-2026-002', '4', 'PG-DEL-44120', '21800.00', 'received', '1', '2026-08-19 14:34:13', 'Personal care and laundry detergent bulk order', '2026-08-20 14:34:13');

-- -----------------------------------------------------------------------------
-- Table structure for `role_permissions`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(50) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_permission` (`role`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  KEY `idx_role` (`role`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `role_permissions` (51 records)
INSERT INTO `role_permissions` (`id`, `role`, `permission_id`, `created_at`) VALUES
('140', 'admin', '2', '2026-08-22 11:12:20'),
('141', 'cashier', '2', '2026-08-22 11:12:20'),
('142', 'admin', '1', '2026-08-22 11:12:20'),
('143', 'admin', '11', '2026-08-22 11:12:20'),
('144', 'admin', '9', '2026-08-22 11:12:20'),
('145', 'admin', '10', '2026-08-22 11:12:20'),
('146', 'admin', '25', '2026-08-22 11:12:20'),
('147', 'admin', '24', '2026-08-22 11:12:20'),
('148', 'admin', '17', '2026-08-22 11:12:20'),
('149', 'admin', '18', '2026-08-22 11:12:20'),
('150', 'admin', '23', '2026-08-22 11:12:20'),
('151', 'admin', '12', '2026-08-22 11:12:20'),
('152', 'cashier', '12', '2026-08-22 11:12:20'),
('153', 'admin', '15', '2026-08-22 11:12:20'),
('154', 'cashier', '15', '2026-08-22 11:12:20'),
('155', 'admin', '13', '2026-08-22 11:12:20'),
('156', 'cashier', '13', '2026-08-22 11:12:20'),
('157', 'admin', '14', '2026-08-22 11:12:20'),
('158', 'cashier', '14', '2026-08-22 11:12:20'),
('159', 'admin', '16', '2026-08-22 11:12:20'),
('160', 'admin', '22', '2026-08-22 11:12:20'),
('161', 'admin', '7', '2026-08-22 11:12:20'),
('162', 'admin', '8', '2026-08-22 11:12:20'),
('163', 'admin', '6', '2026-08-22 11:12:20'),
('164', 'admin', '20', '2026-08-22 11:12:20'),
('165', 'admin', '19', '2026-08-22 11:12:20'),
('166', 'admin', '21', '2026-08-22 11:12:20'),
('167', 'admin', '4', '2026-08-22 11:12:20'),
('168', 'admin', '3', '2026-08-22 11:12:20'),
('169', 'admin', '5', '2026-08-22 11:12:20'),
('170', 'manager', '1', '2026-09-03 04:29:10'),
('171', 'manager', '2', '2026-09-03 04:29:10'),
('172', 'manager', '6', '2026-09-03 04:29:10'),
('173', 'manager', '7', '2026-09-03 04:29:10'),
('174', 'manager', '8', '2026-09-03 04:29:10'),
('175', 'manager', '22', '2026-09-03 04:29:10'),
('176', 'manager', '9', '2026-09-03 04:29:10'),
('177', 'manager', '10', '2026-09-03 04:29:10'),
('178', 'manager', '24', '2026-09-03 04:29:10'),
('179', 'manager', '11', '2026-09-03 04:29:10'),
('180', 'manager', '25', '2026-09-03 04:29:10'),
('181', 'manager', '12', '2026-09-03 04:29:10'),
('182', 'manager', '13', '2026-09-03 04:29:10'),
('183', 'manager', '14', '2026-09-03 04:29:10'),
('184', 'manager', '15', '2026-09-03 04:29:10'),
('185', 'manager', '23', '2026-09-03 04:29:10'),
('186', 'manager', '16', '2026-09-03 04:29:10'),
('187', 'manager', '17', '2026-09-03 04:29:10'),
('188', 'manager', '18', '2026-09-03 04:29:10'),
('189', 'manager', '19', '2026-09-03 04:29:10'),
('190', 'manager', '20', '2026-09-03 04:29:10');

-- -----------------------------------------------------------------------------
-- Table structure for `roles`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `default_dashboard` varchar(100) NOT NULL DEFAULT 'dashboard.php',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `roles` (3 records)
INSERT INTO `roles` (`id`, `role_name`, `display_name`, `description`, `is_system`, `default_dashboard`, `created_at`) VALUES
('1', 'admin', 'Administrator', 'Full system access, inventory, sales, users, settings', '1', 'admin/dashboard.php', '2026-08-14 23:16:56'),
('2', 'manager', 'Store Manager', 'Supervises store inventory, purchasing, pricing, customer loyalty, and financial reports', '1', 'admin/dashboard.php', '2026-09-03 04:29:10'),
('3', 'cashier', 'Cashier', 'POS register and transaction checkout', '1', 'cashier/pos.php', '2026-08-14 23:16:56');

-- -----------------------------------------------------------------------------
-- Table structure for `sale_items`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `sale_items`;
CREATE TABLE `sale_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `cost_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `vat_amount` decimal(10,2) DEFAULT 0.00,
  `vatable_amount` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `sale_items_ibfk_2` (`product_id`),
  CONSTRAINT `sale_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `sale_items` (4 records)
INSERT INTO `sale_items` (`id`, `sale_id`, `product_id`, `quantity`, `price`, `cost_price`, `subtotal`, `vat_amount`, `vatable_amount`) VALUES
('19', '19', '72', '1', '280.00', '196.00', '280.00', '0.00', '0.00'),
('20', '20', '146', '1', '370.00', '259.00', '370.00', '0.00', '0.00'),
('21', '20', '184', '1', '91.00', '63.70', '91.00', '0.00', '0.00'),
('22', '20', '113', '1', '152.00', '106.40', '152.00', '0.00', '0.00');

-- -----------------------------------------------------------------------------
-- Table structure for `sales`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cashier_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `vat_amount` decimal(10,2) DEFAULT 0.00,
  `vatable_sales` decimal(10,2) DEFAULT 0.00,
  `non_vatable_sales` decimal(10,2) DEFAULT 0.00,
  `payment` decimal(10,2) NOT NULL,
  `change_amount` decimal(10,2) NOT NULL,
  `discount_type` enum('none','senior_pwd','member','promo','custom') NOT NULL DEFAULT 'none',
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount_reason` text DEFAULT NULL,
  `is_voided` tinyint(1) NOT NULL DEFAULT 0,
  `voided_by` int(11) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `void_reason` text DEFAULT NULL,
  `is_return` tinyint(1) NOT NULL DEFAULT 0,
  `return_approved_by` int(11) DEFAULT NULL,
  `return_approved_at` datetime DEFAULT NULL,
  `payment_method` enum('cash','card','gcash','maya','other') NOT NULL DEFAULT 'cash',
  `payment_reference` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `cashier_id` (`cashier_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `sales` (20 records)
INSERT INTO `sales` (`id`, `cashier_id`, `customer_id`, `total_amount`, `subtotal`, `vat_amount`, `vatable_sales`, `non_vatable_sales`, `payment`, `change_amount`, `discount_type`, `discount_amount`, `discount_reason`, `is_voided`, `voided_by`, `voided_at`, `void_reason`, `is_return`, `return_approved_by`, `return_approved_at`, `payment_method`, `payment_reference`, `created_at`) VALUES
('1', '3', NULL, '78.00', '0.00', '0.00', '0.00', '0.00', '200.00', '122.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-17 15:34:04'),
('2', '3', NULL, '90.00', '0.00', '0.00', '0.00', '0.00', '500.00', '410.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-17 21:41:33'),
('3', '3', NULL, '45.00', '0.00', '0.00', '0.00', '0.00', '232414.00', '232369.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-17 22:05:32'),
('4', '3', NULL, '25.00', '0.00', '0.00', '0.00', '0.00', '30.00', '5.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-17 22:09:24'),
('5', '3', NULL, '45.00', '0.00', '0.00', '0.00', '0.00', '100.00', '55.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-18 15:01:50'),
('6', '3', NULL, '42.00', '0.00', '0.00', '0.00', '0.00', '19999.00', '19957.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-18 15:03:44'),
('7', '3', NULL, '28.00', '0.00', '3.00', '25.00', '0.00', '28.00', '0.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-18 15:22:15'),
('8', '3', NULL, '50.40', '0.00', '5.40', '45.00', '0.00', '50.40', '0.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-18 15:22:48'),
('9', '3', NULL, '47.04', '0.00', '5.04', '42.00', '0.00', '100.00', '52.96', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-18 17:26:07'),
('10', '3', NULL, '28.00', '0.00', '3.00', '25.00', '0.00', '50.00', '22.00', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-18 17:28:11'),
('11', '3', NULL, '50.40', '0.00', '5.40', '45.00', '0.00', '100.00', '49.60', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-18 18:22:03'),
('12', '3', NULL, '134.40', '0.00', '14.40', '120.00', '0.00', '143.00', '8.60', 'none', '0.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-03-20 02:58:07'),
('13', '1', '1', '225.00', '250.00', '24.11', '200.89', '0.00', '500.00', '275.00', 'promo', '25.00', NULL, '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', NULL, '2026-08-20 14:42:49'),
('14', '1', NULL, '120.00', '120.00', '12.86', '107.14', '0.00', '120.00', '0.00', 'none', '0.00', '', '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', '', '2026-08-22 01:23:48'),
('15', '1', NULL, '550.00', '550.00', '58.93', '491.07', '0.00', '800.00', '250.00', 'none', '0.00', '', '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', '', '2026-08-22 01:25:45'),
('16', '1', NULL, '149.00', '149.00', '15.96', '133.04', '0.00', '150.00', '1.00', 'none', '0.00', '', '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', '', '2026-08-22 15:32:21'),
('17', '1', NULL, '142.14', '199.00', '15.23', '126.91', '0.00', '150.00', '7.86', 'senior_pwd', '56.86', '', '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', '', '2026-08-22 15:52:51'),
('18', '1', NULL, '199.00', '199.00', '21.32', '177.68', '0.00', '200.00', '1.00', 'none', '0.00', '', '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', '', '2026-08-22 19:47:16'),
('19', '1', NULL, '280.00', '280.00', '30.00', '250.00', '0.00', '500.00', '220.00', 'none', '0.00', '', '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', '', '2026-09-02 23:56:04'),
('20', '3', NULL, '613.00', '613.00', '65.68', '547.32', '0.00', '1000.00', '387.00', 'none', '0.00', '', '0', NULL, NULL, NULL, '0', NULL, NULL, 'cash', '', '2026-09-03 04:26:36');

-- -----------------------------------------------------------------------------
-- Table structure for `security_firewall_logs`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `security_firewall_logs`;
CREATE TABLE `security_firewall_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `endpoint` varchar(255) NOT NULL,
  `http_method` varchar(10) NOT NULL DEFAULT 'GET',
  `threat_type` varchar(50) NOT NULL,
  `threat_score` int(11) NOT NULL DEFAULT 10,
  `details` text DEFAULT NULL,
  `payload_snippet` text DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `action_taken` enum('blocked','logged','throttled','banned') NOT NULL DEFAULT 'blocked',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_threat` (`threat_type`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `security_firewall_logs` (2 records)
INSERT INTO `security_firewall_logs` (`id`, `ip_address`, `user_id`, `endpoint`, `http_method`, `threat_type`, `threat_score`, `details`, `payload_snippet`, `user_agent`, `action_taken`, `created_at`) VALUES
('1', '127.0.0.1', NULL, '/Triple8/login.php', 'GET', 'SQL_INJECTION', '40', 'UNION SELECT attack in GET:test', 'UNION SELECT 1,2,3', 'curl/7.88.1', 'blocked', '2026-08-14 23:50:15'),
('2', '127.0.0.1', NULL, '/Triple8/resend_verification.php', 'GET', 'RATE_LIMIT_EXCEEDED', '15', 'Rate limit exceeded (12 req/min)', 'Count: 13', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'blocked', '2026-08-18 17:04:20');

-- -----------------------------------------------------------------------------
-- Table structure for `security_ip_rules`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `security_ip_rules`;
CREATE TABLE `security_ip_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `rule_type` enum('blacklist','whitelist','autoban') NOT NULL DEFAULT 'blacklist',
  `reason` varchar(255) NOT NULL,
  `failed_count` int(11) NOT NULL DEFAULT 1,
  `expires_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_rule_type` (`rule_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `security_rate_limits`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `security_rate_limits`;
CREATE TABLE `security_rate_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `endpoint_hash` varchar(64) NOT NULL,
  `request_count` int(11) NOT NULL DEFAULT 1,
  `window_start` int(11) NOT NULL,
  `last_request_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_ip_endpoint` (`ip_address`,`endpoint_hash`),
  KEY `idx_last_request` (`last_request_time`)
) ENGINE=InnoDB AUTO_INCREMENT=543 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `security_rate_limits` (3 records)
INSERT INTO `security_rate_limits` (`id`, `ip_address`, `endpoint_hash`, `request_count`, `window_start`, `last_request_time`) VALUES
('1', '127.0.0.1', 'c47460456bcc17442ec53198a9ed5c91', '8', '1787369835', '1787369892'),
('2', '127.0.0.1', '528b694a7e8eca57ab1619f3f55a5d29', '2', '1786723000', '1786723000'),
('15', '127.0.0.1', '36a9dc295ecc2e8969b54219398cb3be', '7', '1787364912', '1787364951');

-- -----------------------------------------------------------------------------
-- Table structure for `security_settings`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `security_settings`;
CREATE TABLE `security_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `security_settings` (10 records)
INSERT INTO `security_settings` (`id`, `setting_key`, `setting_value`, `updated_at`) VALUES
('1', 'waf_mode', 'active_blocking', '2026-08-14 23:36:11'),
('2', 'rate_limit_standard', '120', '2026-08-14 23:36:11'),
('3', 'rate_limit_auth', '12', '2026-08-14 23:36:11'),
('4', 'rate_limit_api', '90', '2026-08-14 23:36:11'),
('5', 'autoban_threat_threshold', '5', '2026-08-14 23:36:11'),
('6', 'autoban_duration_hours', '24', '2026-08-14 23:36:11'),
('7', 'inspect_sqli', '1', '2026-08-14 23:36:11'),
('8', 'inspect_xss', '1', '2026-08-14 23:36:11'),
('9', 'inspect_traversal', '1', '2026-08-14 23:36:11'),
('10', 'block_bad_bots', '1', '2026-08-14 23:36:11');

-- -----------------------------------------------------------------------------
-- Table structure for `stock_adjustments`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `stock_adjustments`;
CREATE TABLE `stock_adjustments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `adjustment_type` enum('damage','expired','shrinkage','stocktake','correction') NOT NULL,
  `quantity_change` int(11) NOT NULL,
  `previous_stock` int(11) NOT NULL,
  `new_stock` int(11) NOT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `stock_adjustments_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `stock_adjustments` (102 records)
INSERT INTO `stock_adjustments` (`id`, `product_id`, `user_id`, `adjustment_type`, `quantity_change`, `previous_stock`, `new_stock`, `reason`, `created_at`) VALUES
('1', '69', '1', 'stocktake', '4', '50', '54', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('2', '72', '1', 'stocktake', '80', '39', '119', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('3', '80', '1', 'stocktake', '38', '25', '63', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('4', '91', '1', 'stocktake', '37', '0', '37', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('5', '92', '1', 'stocktake', '54', '0', '54', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('6', '94', '1', 'stocktake', '75', '0', '75', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('7', '95', '1', 'stocktake', '101', '0', '101', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('8', '96', '1', 'stocktake', '78', '0', '78', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('9', '97', '1', 'stocktake', '64', '0', '64', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('10', '98', '1', 'stocktake', '50', '0', '50', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('11', '99', '1', 'stocktake', '45', '0', '45', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('12', '100', '1', 'stocktake', '59', '0', '59', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('13', '101', '1', 'stocktake', '108', '0', '108', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('14', '102', '1', 'stocktake', '177', '0', '177', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('15', '103', '1', 'stocktake', '70', '0', '70', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('16', '104', '1', 'stocktake', '80', '0', '80', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('17', '105', '1', 'stocktake', '92', '0', '92', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('18', '106', '1', 'stocktake', '72', '0', '72', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('19', '107', '1', 'stocktake', '61', '0', '61', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('20', '108', '1', 'stocktake', '74', '0', '74', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('21', '109', '1', 'stocktake', '72', '0', '72', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('22', '110', '1', 'stocktake', '43', '0', '43', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('23', '111', '1', 'stocktake', '77', '0', '77', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('24', '112', '1', 'stocktake', '44', '0', '44', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('25', '113', '1', 'stocktake', '57', '0', '57', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('26', '114', '1', 'stocktake', '42', '0', '42', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('27', '115', '1', 'stocktake', '29', '0', '29', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('28', '116', '1', 'stocktake', '43', '0', '43', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('29', '117', '1', 'stocktake', '55', '0', '55', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('30', '118', '1', 'stocktake', '51', '0', '51', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('31', '119', '1', 'stocktake', '59', '0', '59', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('32', '120', '1', 'stocktake', '29', '0', '29', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('33', '121', '1', 'stocktake', '32', '0', '32', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('34', '122', '1', 'stocktake', '80', '0', '80', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('35', '123', '1', 'stocktake', '111', '0', '111', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('36', '124', '1', 'stocktake', '93', '0', '93', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('37', '125', '1', 'stocktake', '64', '0', '64', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('38', '126', '1', 'stocktake', '83', '0', '83', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('39', '127', '1', 'stocktake', '59', '0', '59', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('40', '128', '1', 'stocktake', '113', '0', '113', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('41', '129', '1', 'stocktake', '68', '0', '68', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('42', '130', '1', 'stocktake', '55', '0', '55', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('43', '131', '1', 'stocktake', '111', '0', '111', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('44', '132', '1', 'stocktake', '73', '0', '73', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('45', '133', '1', 'stocktake', '52', '0', '52', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('46', '134', '1', 'stocktake', '79', '0', '79', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('47', '135', '1', 'stocktake', '59', '0', '59', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('48', '136', '1', 'stocktake', '83', '0', '83', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('49', '137', '1', 'stocktake', '41', '0', '41', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('50', '138', '1', 'stocktake', '38', '0', '38', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('51', '139', '1', 'stocktake', '43', '0', '43', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('52', '140', '1', 'stocktake', '61', '0', '61', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('53', '141', '1', 'stocktake', '28', '0', '28', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('54', '142', '1', 'stocktake', '75', '0', '75', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('55', '143', '1', 'stocktake', '69', '0', '69', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('56', '144', '1', 'stocktake', '67', '0', '67', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('57', '145', '1', 'stocktake', '134', '0', '134', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('58', '146', '1', 'stocktake', '34', '0', '34', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('59', '147', '1', 'stocktake', '55', '0', '55', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('60', '148', '1', 'stocktake', '42', '0', '42', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('61', '149', '1', 'stocktake', '47', '0', '47', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('62', '150', '1', 'stocktake', '48', '0', '48', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('63', '151', '1', 'stocktake', '72', '0', '72', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('64', '152', '1', 'stocktake', '37', '0', '37', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('65', '153', '1', 'stocktake', '63', '0', '63', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('66', '154', '1', 'stocktake', '96', '0', '96', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('67', '155', '1', 'stocktake', '46', '0', '46', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('68', '156', '1', 'stocktake', '45', '0', '45', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('69', '157', '1', 'stocktake', '71', '0', '71', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('70', '158', '1', 'stocktake', '54', '0', '54', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('71', '159', '1', 'stocktake', '35', '0', '35', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('72', '160', '1', 'stocktake', '40', '0', '40', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('73', '161', '1', 'stocktake', '52', '0', '52', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('74', '162', '1', 'stocktake', '30', '0', '30', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('75', '163', '1', 'stocktake', '61', '0', '61', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('76', '164', '1', 'stocktake', '222', '0', '222', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('77', '165', '1', 'stocktake', '189', '0', '189', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('78', '166', '1', 'stocktake', '150', '0', '150', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('79', '167', '1', 'stocktake', '179', '0', '179', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('80', '168', '1', 'stocktake', '123', '0', '123', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('81', '169', '1', 'stocktake', '142', '0', '142', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('82', '170', '1', 'stocktake', '90', '0', '90', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('83', '171', '1', 'stocktake', '50', '0', '50', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('84', '172', '1', 'stocktake', '58', '0', '58', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('85', '173', '1', 'stocktake', '53', '0', '53', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('86', '174', '1', 'stocktake', '41', '0', '41', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('87', '175', '1', 'stocktake', '62', '0', '62', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('88', '176', '1', 'stocktake', '39', '0', '39', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('89', '177', '1', 'stocktake', '45', '0', '45', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('90', '178', '1', 'stocktake', '55', '0', '55', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('91', '179', '1', 'stocktake', '99', '0', '99', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('92', '180', '1', 'stocktake', '179', '0', '179', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('93', '181', '1', 'stocktake', '131', '0', '131', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('94', '182', '1', 'stocktake', '178', '0', '178', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('95', '183', '1', 'stocktake', '119', '0', '119', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('96', '184', '1', 'stocktake', '34', '0', '34', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('97', '185', '1', 'stocktake', '42', '0', '42', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('98', '186', '1', 'stocktake', '35', '0', '35', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('99', '187', '1', 'stocktake', '59', '0', '59', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('100', '188', '1', 'stocktake', '36', '0', '36', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31');
INSERT INTO `stock_adjustments` (`id`, `product_id`, `user_id`, `adjustment_type`, `quantity_change`, `previous_stock`, `new_stock`, `reason`, `created_at`) VALUES
('101', '189', '1', 'stocktake', '41', '0', '41', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31'),
('102', '190', '1', 'stocktake', '46', '0', '46', 'Initial inventory stock count and stock-in setup', '2026-09-03 04:15:31');

-- -----------------------------------------------------------------------------
-- Table structure for `suppliers`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `suppliers` (7 records)
INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `phone`, `email`, `address`, `status`, `created_at`) VALUES
('1', 'Universal Robina Corporation', 'Carlos Mendoza', '+63 917 555 1001', 'sales@urc.com.ph', 'Pasig City, Metro Manila', 'active', '2026-08-20 14:32:53'),
('2', 'Nestlé Philippines Inc.', 'Ma. Teresa Ramos', '+63 918 555 2002', 'orders@ph.nestle.com', 'Makati City, Metro Manila', 'active', '2026-08-20 14:32:53'),
('3', 'San Miguel Foods & Beverage', 'Eduardo Santos', '+63 920 555 3003', 'distributors@sanmiguel.com.ph', 'Mandaluyong City, Metro Manila', 'active', '2026-08-20 14:32:53'),
('4', 'Procter & Gamble Philippines', 'Patricia De Leon', '+63 917 555 4004', 'phorders@pg.com', 'BGC, Taguig City', 'active', '2026-08-20 14:32:53'),
('5', 'Unilever Philippines', 'Antonio Cruz', '+63 919 555 5005', 'customercare@unilever.ph', 'Paco, Manila', 'active', '2026-08-20 14:32:53'),
('6', 'Coca-Cola Beverages Philippines', 'Grace Villanueva', '+63 917 555 6006', 'orders@coca-cola.com.ph', 'Taguig City, Metro Manila', 'active', '2026-08-20 14:32:53'),
('7', 'Monde Nissin Corporation', 'Roberto Garcia', '+63 922 555 7007', 'sales@mondenissin.com', 'Sta. Rosa, Laguna', 'active', '2026-08-20 14:32:53');

-- -----------------------------------------------------------------------------
-- Table structure for `system_heartbeat`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `system_heartbeat`;
CREATE TABLE `system_heartbeat` (
  `id` int(11) NOT NULL DEFAULT 1,
  `last_ping` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `clean_shutdown` tinyint(1) NOT NULL DEFAULT 1,
  `last_shutdown_at` timestamp NULL DEFAULT NULL,
  `crash_detected_at` timestamp NULL DEFAULT NULL,
  `crash_resolved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `system_heartbeat` (1 records)
INSERT INTO `system_heartbeat` (`id`, `last_ping`, `clean_shutdown`, `last_shutdown_at`, `crash_detected_at`, `crash_resolved`) VALUES
('1', '2026-08-26 19:38:59', '0', NULL, NULL, '1');

-- -----------------------------------------------------------------------------
-- Table structure for `system_settings`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `system_settings` (29 records)
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `description`, `updated_at`) VALUES
('1', 'store_name', 'Triple8 Retail Store', NULL, '2026-08-21 22:23:28'),
('2', 'store_address', 'Balingasag, Misamis Oriental', NULL, '2026-08-21 22:23:28'),
('3', 'store_phone', '(02) 8888-0888 / +63 917 888 8888', NULL, '2026-08-20 14:32:53'),
('4', 'tax_rate', '12', NULL, '2026-08-20 14:32:53'),
('5', 'currency_symbol', '₱', NULL, '2026-08-20 14:32:53'),
('26', 'vat_rate', '12', 'VAT rate in percent (e.g., 12 for 12%)', '2026-03-18 15:21:28'),
('27', 'vat_enabled', '1', 'Enable VAT calculations', '2026-03-18 15:21:28'),
('28', 'vat_description', 'VAT', 'VAT description on receipts', '2026-03-18 15:21:28'),
('29', 'non_vatable_description', 'Non-VATable', 'Non-VATable description on receipts', '2026-03-18 15:21:28'),
('40', 'max_image_size', '2048', NULL, '2026-03-20 01:18:09'),
('41', 'allowed_image_types', 'jpg,jpeg,png,gif', NULL, '2026-03-20 01:18:09'),
('42', 'product_image_width', '800', NULL, '2026-03-20 01:18:09'),
('43', 'product_image_height', '600', NULL, '2026-03-20 01:18:09'),
('55', 'store_tagline', 'Your Everyday One-Stop Supermarket', NULL, '2026-08-20 14:32:53'),
('56', 'store_email', 'store@triple8retail.com', NULL, '2026-08-20 14:32:53'),
('57', 'store_tin', '248-888-888-000-VAT', NULL, '2026-08-20 14:32:53'),
('58', 'receipt_header', 'WELCOME TO TRIPLE8 RETAIL STORE\r\nOfficial Sales Invoice / POS Receipt', NULL, '2026-08-21 22:23:28'),
('59', 'receipt_footer', 'Thank you for shopping at Triple8 Superstore!\r\nPlease present receipt for exchanges within 7 days.', NULL, '2026-08-21 22:23:28'),
('60', 'loyalty_points_rate', '100', NULL, '2026-08-20 14:32:53'),
('72', 'backup_auto_enabled', '1', NULL, '2026-08-26 19:33:49'),
('73', 'backup_frequency_minutes', '60', NULL, '2026-08-26 19:33:49'),
('74', 'backup_on_sale', '1', NULL, '2026-08-26 19:33:49'),
('75', 'backup_on_sale_interval_count', '5', NULL, '2026-08-26 19:33:49'),
('76', 'backup_retention_count', '30', NULL, '2026-08-26 19:33:49'),
('77', 'backup_compression', '1', NULL, '2026-08-26 19:33:49'),
('78', 'backup_storage_path', 'backups/', NULL, '2026-08-26 19:33:49'),
('79', 'backup_cron_token', 't8_bkp_e8f29c4701a39b542017d84a', NULL, '2026-08-26 19:33:49'),
('80', 'backup_last_run', '2026-09-02 20:40:43', NULL, '2026-09-02 20:40:43'),
('81', 'backup_power_loss_protection', '1', NULL, '2026-08-26 19:33:49');

-- -----------------------------------------------------------------------------
-- Table structure for `user_permissions`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `is_granted` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_permission` (`user_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `user_permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- -----------------------------------------------------------------------------
-- Table structure for `users`
-- -----------------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT 1,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'cashier',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_last_login` (`last_login`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table `users` (4 records)
INSERT INTO `users` (`id`, `username`, `email`, `email_verified`, `password`, `role`, `status`, `created_at`, `last_login`) VALUES
('1', 'admin', 'abregana.archjulian@gmail.com', '1', '$2y$10$NMjnQUVndoPmojJaBORz8.V0NS7GexOOqjXM142Icil90knKhOXd2', 'admin', 'active', '2026-03-17 02:59:39', '2026-09-03 04:26:51'),
('2', 'manager1', NULL, '1', '$2y$10$G40iTMgnwtzfUBZScNnX.OdjRXUfNsWp.WhFNG/9HEiPsv2j89iHy', 'cashier', 'active', '2026-03-17 02:59:39', '2026-03-20 03:50:23'),
('3', 'cashier1', NULL, '1', '$2y$10$AqSmiNGF5dNYplacjwgugOdqLu58chdPTuRg9SnObnlTeEjM1h/ty', 'cashier', 'active', '2026-03-17 02:59:39', '2026-09-03 04:26:25'),
('5', 'inventory1', 'inventory@triple8retail.com', '1', '$2y$10$alJr6e0S7ChYO2D7IbcVvu2zMvH7SGBWsR1gTC6.upWzBsuUFj.LW', 'cashier', 'active', '2026-08-20 14:34:22', NULL);

COMMIT;
SET FOREIGN_KEY_CHECKS=1;
-- End of Triple8 Backup Dump
